<script src="<?php echo base_url('assets/RuangAdmin-master/vendor/jquery/jquery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/RuangAdmin-master/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/RuangAdmin-master/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/RuangAdmin-master/js/ruang-admin.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/RuangAdmin-master/vendor/chart.js/Chart.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/RuangAdmin-master/js/demo/chart-area-demo.js'); ?>"></script> 